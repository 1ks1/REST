<?PHP

//header('Content-Type: application/pdf');
// Он будет называться downloaded.pdf
//header('Content-Disposition: attachment; filename="downloaded.pdf"');
// Исходный PDF-файл original.pdf
//readfile('original.pdf');

//header('Content-Type: text/javascript');
//header('Content-Type: text/css');
//header('Content-Type: text/html; charset=utf-8'); 
//header('Content-Type: image/gif'); 
//header('Content-Type: image/png'); 
//header('Content-Type: image/jpg'); 
//header('Content-Type: application/json');
//header("Location: http://www.example.com/");
//header("HTTP/1.0 404 Not Found");

class Test
{
    protected $url;
    protected $method;
    protected $parameters;

    function __construct()
    {
        $this->url = explode('/',$_SERVER['REQUEST_URI']);
        $isApi = false;
        $isMethod = false;
        $parameters = [];

        //PARSING URL
        foreach($this->url as $value)
        {
            $value = $this->validator($value);


            if ($isApi)
            {
                $this->parameters[] = $value;
            }

            if (strtolower(trim($value)) == 'api')
            {
                $isApi = true;
            }

        }
        $this->method = $this->parameters[0];
        $this->methodCheck($this->method);
    }


    function validator($str)
    {
        $str = htmlspecialchars(trim($str));
        return $str;
    }


        ///METHODS SELECTOR
    function methodCheck($method)
    { 
        switch($method) 
        {
        case 'sayhello':
            if (count($this->parameters) > 0)
            {
                $this->sayHello($this->parameters[1]);
            }else{$this->sayHello();}
        
            break;

        case 1:
            echo "i равно 1";
            break;
        case 2:
            echo "i равно 2";
            break;
        }
    }


    function sayHello($name = false)
    {
        if (!$name)
        $res = 'Hello guest!';
        if ($name)
        $res = 'Hello, ' . $name . '!';
        header('Content-Type: application/json'); 
        echo json_encode(['echo'=>$res]);
    }


}

$cl = new Test($_SERVER['REQUEST_METHOD']);
echo "<pre>";
echo 'REQUEST Method:';
print_r($_SERVER['REQUEST_METHOD']);
echo "\n";
$arr = explode('/',$_SERVER['REQUEST_URI']);
echo 'api Method: ' . $arr[4];
echo " \n";
if (isset($arr[5]) && !empty($arr[5]))
{
    echo 'parameter 1: ' . $arr[5];
    echo " \n";
}
echo " URL: \n";
print_r($_SERVER['REQUEST_URI']);
// $data = [
// 'remote_host'=>$_SERVER['REMOTE_ADDR']
// ];
// $data ['url'] = explode('/',$_SERVER['REQUEST_URI']);
// echo json_encode($data);