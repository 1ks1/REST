<?PHP

//header('Content-Type: application/pdf');
// Он будет называться downloaded.pdf
//header('Content-Disposition: attachment; filename="downloaded.pdf"');
// Исходный PDF-файл original.pdf
//readfile('original.pdf');

//header('Content-Type: text/javascript');
//header('Content-Type: text/css');
//header('Content-Type: text/html; charset=utf-8'); 
//header('Content-Type: image/gif'); 
//header('Content-Type: image/png'); 
//header('Content-Type: image/jpg'); 
//header('Content-Type: application/json');
//header("Location: http://www.example.com/");
//header("HTTP/1.0 404 Not Found");

class Test
{
    protected $url;
    protected $metgod;

    function __construct()
    {
        $this->url = explode('/',$_SERVER['REQUEST_URI']);
    }

    function setMethod($method)
    {
        $this->method = $method;
    }

}

$cl = new Test;
echo "<pre>";
echo 'REQUEST Method:';
print_r($_SERVER['REQUEST_METHOD']);
echo "\n";
$arr = explode('/',$_SERVER['REQUEST_URI']);
echo 'api Method: ' . $arr[4];
echo " \n";
if (isset($arr[5]) && !empty($arr[5]))
{
    echo 'parameter 1: ' . $arr[5];
    echo " \n";
}
echo " URL: \n";
print_r($_SERVER['REQUEST_URI']);
// $data = [
// 'remote_host'=>$_SERVER['REMOTE_ADDR']
// ];
// $data ['url'] = explode('/',$_SERVER['REQUEST_URI']);
// echo json_encode($data);