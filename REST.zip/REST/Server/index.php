<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>REST</title>
</head>
<body>
	<?PHP echo  __DIR__  . "<br />"; ?>
	<?PHP print_r( __FILE__ ); ?>
</body>
</html>