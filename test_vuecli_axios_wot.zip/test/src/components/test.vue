<template>
  <div class="hello">
      <h1>THIS IS TEST</h1>
    {{msg}}
  </div>
</template>

<script>
export default {
  name: 'test',
  data () {
    return {
      msg: 'TEST'
    }
  }
}
</script>