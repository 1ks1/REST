<?PHP
///////////////////////////
///servers methods      ///
///databse parent class ///
///want to do config errors
///have no valid emails yet
///////////////////////////

include ('DB.php');
class Service extends DB
{

    function putTest($params = false)
    {   
        if ($params == false || strtolower($params[0]) == 'test')
        return ['noparams'=>'OK'];
        array_shift($params);
        return $params;
    }

    function getShowCars($id = false)
    {
        if ($id !== false)
        $q = 'select * from cars';

        if (isset($id[0]) && is_numeric($id[0]) )
        $q = 'select * from cars where id=' . $id[0];

        $stmt = $this->pdo->prepare($q);
        $stmt->execute();
        $res = $stmt->fetchAll();
        return $res;
    }
	function getCrypt($p = '')
	{
	if (is_array($p))
		$p = $p[0];
	if (strlen($p) < 1 || $p == 'Crypt')
		return 'Please enter yo string';
	$clearTextPassword = $p;
	// Encrypt password
	$password = crypt($clearTextPassword, base64_encode($clearTextPassword));
	return $password;
    }
    
    function getMd5($p = '')
	{
	if (is_array($p))
		$p = $p[0];
	if (strlen($p) < 1 || $p == 'Md5')
		return 'Please enter yo string';
	return md5($p);
	}
	
    function getHelp($id = false)
    {
        $res = get_class_methods($this);
        return $res;
    }

    function strValid($str)
    {
        $str = htmlspecialchars(trim($str));
        if (strlen($str)<1)
        return false;
        return $str;
    }

    function postReg($userData)
    {   
        $key        = '';
        $regstatus  = '';

        if (!(isset($userData['email']) || 
            isset($userData['password']) ||
            isset($userData['confirmpassword']) ||
            isset($userData['firstname']) ||
            isset($userData['lastname'])))
            return ['regstatus'=>'fields empty'];

        if (strlen($userData['email']) < 5)
        return ['regstatus'=>'email error'];
        
        $eml    = $userData['email'];
        $p      = $userData['password'];
        $c      = $userData['confirmpassword'];
        $f      = $userData['firstname'];
        $l      = $userData['lastname'];

        if ($p !== $c)
        return ['regstatus'=>'confirm password'];

        if ((strlen($f) < 3) || (strlen($l) < 3))
        return ['regstatus'=>'Name < 3 letters!'];

        $q      = 'select count(email) from users where email=' . "'$eml'";
        $stmt   = $this->pdo->prepare($q);
        $stmt->execute();
        $res    = $stmt->fetchAll();
        
        if (is_array($res) && $res[0]['count(email)'] > 0)
        {
            $regstatus = 'User exists!';
        } 
        else 
        {
            try
            {
                $p = md5($p);
                $q = 'INSERT INTO users ' .
                "(name,lastname,email,password)" . 
                " values ('$f','$l','$eml','$p') ";
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();
                //key - типа токен для чайников
                $key = $p;
                $regstatus='OK';
            }
            catch(PDOException $e) 
            {  
                //$result = 'Reg db error!' . $e->getMessage();
                $regstatus='Error' . $e->getMessage();
            }
            //$stmt->execute();
        }

        return ['regstatus'=>$regstatus,'email'=>$eml,'key'=>$key];
    }

    function postLogin($userData)
    {
        if (empty($userData['email']))
        return ['loginstatus'=>'email is wrong'];

        if (empty($userData['password']))
        return ['loginstatus'=>'password is wrong'];

        if (strlen($userData['email']) < 5 || strlen($userData['password']) < 6)
        return ['loginstatus'=>'fields is too short'];

        $name = '';
        $key = '';
        $loginstatus = 'NotAutorize';
        $eml    = $userData['email'];
        $p      = $userData['password'];
        $ph     = md5($p);//<-хочу быть токеном
        $q      = 'SELECT name,email,password from users WHERE ' .
                "email='$eml' and password='$ph'";

            try
            {
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();
                $res = $stmt->fetchAll();
                if (count($res)>0)
                {
                    $key    = $ph;
                    $name   = $res[0]['name'];
                    $loginstatus='OK';
                } else {
                    $loginstatus='Wrong user or password';
                } 
            }
            catch(PDOException $e) 
            {  
                $loginstatus='Error' . $e->getMessage();
            }

        return ['loginstatus'=>$loginstatus,'key'=>$key,'email'=>$eml,'name'=>$name];
    }

   
    

   
}