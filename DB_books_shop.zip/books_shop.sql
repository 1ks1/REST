CREATE TABLE `b_books` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(250) NOT NULL,
	`genre_id` INT(11) NOT NULL,
	`autor_id` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `b_autors` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(250) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `b_genres` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(250) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `b_ba` (
	`b_id` INT(11) NOT NULL,
	`a_id` INT(11) NOT NULL
);

CREATE TABLE `b_bg` (
	`b_id` INT(11) NOT NULL,
	`g_id` INT(11) NOT NULL
);

CREATE TABLE `b_users` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`email` varchar(250) NOT NULL UNIQUE,
	`password` varchar(250) NOT NULL,
	`token` varchar(250) NOT NULL,
	`banned` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `b_orders` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`user_id` INT NOT NULL,
	`date` INT NOT NULL,
	`payment` INT NOT NULL,
	`delivery_address` varchar(250) NOT NULL,
	`status` INT NOT NULL,
	`color` varchar(250) NOT NULL,
	`total_price` INT(11) NOT NULL,
	`discont_client` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `b_order_detail` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`product_id` INT(11) NOT NULL,
	`price` INT(11) NOT NULL,
	`discont` INT(11) NOT NULL,
	`order_id` INT(11) NOT NULL,
	`count` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `b_cart` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`product_id` INT(11) NOT NULL,
	`count` INT(11) NOT NULL,
	`user_id` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `b_discont_client` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`discont` INT(11) NOT NULL,
	`user_id` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `b_discont_product` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`discont` INT(11) NOT NULL,
	`product_id` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

ALTER TABLE `b_ba` ADD CONSTRAINT `b_ba_fk0` FOREIGN KEY (`b_id`) REFERENCES `b_books`(`id`);

ALTER TABLE `b_ba` ADD CONSTRAINT `b_ba_fk1` FOREIGN KEY (`a_id`) REFERENCES `b_autors`(`id`);

ALTER TABLE `b_bg` ADD CONSTRAINT `b_bg_fk0` FOREIGN KEY (`b_id`) REFERENCES `b_books`(`id`);

ALTER TABLE `b_bg` ADD CONSTRAINT `b_bg_fk1` FOREIGN KEY (`g_id`) REFERENCES `b_genres`(`id`);

ALTER TABLE `b_orders` ADD CONSTRAINT `b_orders_fk0` FOREIGN KEY (`user_id`) REFERENCES `b_users`(`id`);

ALTER TABLE `b_orders` ADD CONSTRAINT `b_orders_fk1` FOREIGN KEY (`payment`) REFERENCES `b_payment`(`id`);

ALTER TABLE `b_orders` ADD CONSTRAINT `b_orders_fk2` FOREIGN KEY (`discont_client`) REFERENCES `b_discont_client`(`id`);

ALTER TABLE `b_order_detail` ADD CONSTRAINT `b_order_detail_fk0` FOREIGN KEY (`product_id`) REFERENCES `b_books`(`id`);

ALTER TABLE `b_order_detail` ADD CONSTRAINT `b_order_detail_fk1` FOREIGN KEY (`order_id`) REFERENCES `b_orders`(`id`);

ALTER TABLE `b_cart` ADD CONSTRAINT `b_cart_fk0` FOREIGN KEY (`user_id`) REFERENCES `b_users`(`id`);

ALTER TABLE `b_discont_client` ADD CONSTRAINT `b_discont_client_fk0` FOREIGN KEY (`user_id`) REFERENCES `b_users`(`id`);

ALTER TABLE `b_discont_product` ADD CONSTRAINT `b_discont_product_fk0` FOREIGN KEY (`product_id`) REFERENCES `b_books`(`id`);

