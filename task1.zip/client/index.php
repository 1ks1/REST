<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
    <style>
    h1 {text-align:center;}
		body {
            margin:0;
            padding:0;
            font-family: "Roboto Condensed","Arial Narrow",Arial,sans-serif;
			background-image: url('//ru-wotp.wgcdn.co/dcont/fb/image/inbetweener-trade-in-wz-120.jpg');
            background-repeat: none;
			color:#fab81b;
			text-shadow:0 0 2px #000;
            text-transform: uppercase;
		}
        .forms_autorize{
            text-align:center;
        }
        .forms_autorize #result_form{
            text-align:center;
            background:#bc2515;
            color:#fffbed;
            border-radius:20%;
            border:#fff;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            font-family: "Roboto Condensed","Arial Narrow",Arial,sans-serif;
            width:250px;
            margin: 0 auto;
            padding:0 6px;
        }
        form {
            font-family: "Roboto Condensed","Arial Narrow",Arial,sans-serif;
            width:205px;
            padding:2px 5px;
            background:#ccc;
            margin:5px auto;
            color:#008;
            box-shadow:1px 2px 3px #000;
            border-radius:2px;
        }
        form input,form button{
            border:1px solid rgba(254,0,0,.3);
            width:200px;
            border-radius:3px;
            margin: 1px;
            background:#fff;
            cursor:default;
        }
        form button{
            background:linear-gradient(#000,#ccc,#abc);
            color:#fff;
            font-weight:600;
            font-family:Verdana,Arial;
            text-shadow:0 0 2px #000;
            cursor:pointer;
        }
        .main {background:rgba(220,220,250,0.2);}
			
        .cars-list .car {
            background:linear-gradient(#fff,#ddd);
            width: 220px;
            float: left;
            border: 1px solid lightgray;
            border-radius: 5px;
			box-shadow:2px 3px 5px #ccc;
            padding: 2px;
            margin: 5px 2px;
        }

        .cars-list .car > h3{
            margin-top: 0;
			color:#777;
            text-transform: capitalize;
            text-align: center;
			text-shadow: 0px  -1px 1px #008, 0px 1px 1px #000;
        }
		.cars-list .car > h4{
            margin-top: 0;
			color:gray;
            text-transform: capitalize;
            text-align: center;
        }
		.cars-list .car > .price{
            margin-top: 0;
			color:#352b02;
            text-transform: capitalize;
            text-align: center;
        }

        .cars-list::after {
            clear: both;
        }

        .cars-list::after,
        .cars-list::before{
            content: " ";
            display: table;
        }

        .usr  {
            position:fixed;
            left:5px;
            top:0;
            background:linear-gradient(#fffbed,#aaa8d8);
            padding:0;
            margin:0;
            border:1px solid #ccc;
            box-shadow:2px 2px 3px #000;
        }
        .usr .uid-stat, .usr a,{
            padding:0;
            margin:0;
        }
    </style>
<body>
<div class="main">
    <h1>Cars Shop Client</h1>
    <div class="forms_autorize">
        <div id="result_form"></div>
        
            <!-- registration-->
        <div class="form_user_registration">
            <form action="" id="registration_form" method="POST">
            <span>register</span>
            <input type="text" name="firstname" placeholder="firstname"><br />
            <input type="text" name="lastname" placeholder="lastname"><br />
            <input type="text" name="email" placeholder="email"><br />
            <input type="password" name="password" ><br />
            <input type="password" name="confirmpassword"><br />
            <button name="send" id="btn">SEND</button>
            </form>
        </div>
        <!-- login -->
        <div class="form_user_login">
                <form action="" id="login_form" method="POST">
                <span>login</span>
                <input type="text" name="email" placeholder="email"><br />
                <input type="password" name="password"><br />
                <button name="sendLogin" id="btn_login">SEND</button>
                </form>
        </div>
    </div>
    <div class="uid-stat" id="uid"></div>
    <div class="cars-list" id="cars"></div>
</div>


    <script type="text/template" id="template_cars">
        <div class="car">
            <h3 class="js_car_model"></h3>
			<h4 class="js_car_year"></h4>
			<span class="js_car_price price"></span>
        </div>
    </script>

    <script type="text/template" id="template_uid">
        <div class="usr">
            <span class="msg_login"></span>
        </div>
    </script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script>
	var $url_serv = 'http://192.168.0.8/REST/Server/api/';
        (function($){
            var $login = getCookie('key');
            if ($login == undefined){$login = '0';} 
            var $cars = $('#cars');
            var $uid = $('#uid');
            var template_cars = $('#template_cars').text();

            var template_uid = $('#template_uid').text();
            var $usr = $(template_uid);
            if ($login.length > 5 ){
                $usr.find('.msg_login').html('<a href="#" id="logout">LOGOUT</a>');
            }
            $usr.appendTo($uid);

            function buildCars(data) {
                $(data).each(function(index, val) {
                    var $car = $(template_cars);
					//console.log(val);
                    $car.find('.js_car_model').text(val.model);
					$car.find('.js_car_year').text(val.year);
                    if ($login.length > 5){
                        console.log($login);
                        $car.find('.js_car_price').html('('+val.id+') '+val.price+'$ <b>Bay</b>');
                    }else{
                        $car.find('.js_car_price').text(val.price+'$');
                    }
                    $car.appendTo($cars);
                });
            }

            $.ajax({
                url: $url_serv+'ShowCars/',
                method: 'GET',
                data: {
                    results: 50,
                    seed: 'test'
                },
                success: function(data) {
                    buildCars(data);
					//console.log(data);
                },
                error: function(e) {
                    console.log('ajax error', e);
                },
                complete: function() {
                    console.log('allways runned')
                }
            })
			

        }(jQuery))

		/////REGISTRATION////
			function sendAjaxForm(result_form, registration_form, url) {
			$.ajax({
                url:     url, //url страницы 
                type:     "POST", //метод отправки
                dataType: "html", //формат данных
                data: $("#"+registration_form).serialize(),  // Сеарилизуем объект
                success: function(response) { //Данные отправлены успешно
                    result = $.parseJSON(response);
					console.log(result.regstatus);
					//result = response;
                    $('#result_form').html('registration: '+result.regstatus);
					
						if (result.regstatus == 'OK'){
						document.cookie = "uid="+result.email;document.cookie = "key="+result.key;
						}else{
							document.cookie = "uid="+result.email;document.cookie = "key";
						}
					
                },
                error: function(response) { // Данные не отправлены
                    $('#result_form').html('Ошибка. Данные не отправлены.');
                }
            });
							
			}
			
			$("#btn").click(
					function(){
						sendAjaxForm('result_form', 'registration_form', $url_serv+'Reg/');
						return false; 
					}
            );

            $("#logout").click(
                function(){
                    alert(document.cookie);
                document.cookie = "uid=0";
                document.cookie = "key=0";
                return false;
                }
            );
			
			
			/////LOGIN USER////
			function sendAjaxLogin(result_form, login_form, url) {
			$.ajax({
                url:     url, //url страницы 
                type:     "POST", //метод отправки
                dataType: "html", //формат данных
                data: $("#"+login_form).serialize(),  // Сеарилизуем объект
                success: function(response) { //Данные отправлены успешно
                    result = $.parseJSON(response);
					console.log(result);
					//result = response;
                    $('#result_form').html('login: '+result.loginstatus);
						if (result.loginstatus == 'OK'){
							document.cookie = "uid="+result.email;document.cookie = "key="+result.key;
						}else{
							document.cookie = "uid="+result.email;document.cookie = "key=0";
						}
                },
                error: function(response) { // Данные не отправлены
                    $('#result_form').html('Ошибка. Данные не отправлены.');
                }
            });
							
			}
			
			$("#btn_login").click(
					function(){
						sendAjaxLogin('result_form', 'login_form', $url_serv+'Login/');
						return false; 
					}
            );
			
			function getCookie(name) {
            var matches = document.cookie.match(new RegExp(
                "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
            ));
            return matches ? decodeURIComponent(matches[1]) : undefined;
            }
       
    </script>
</body>
</html>