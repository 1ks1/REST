<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Document</title>
</head>
    <style>
    h1 {text-align:center;}
		body {
            margin:0;
            padding:0;
            font-family: "Roboto Condensed","Arial Narrow",Arial,sans-serif;
            background:#000;
            background-image: url('pic/inbetweener-trade-in-wz-120.jpg');
            background-repeat: no-repeat;
			color:#fab81b;
			text-shadow:0 0 2px #000;
            text-transform: uppercase;
		}
        .forms_autorize{
            text-align:center;
        }
        .forms_autorize #result_form{
            text-align:center;
            background:#bc2515;
            color:#fffbed;
            border-radius:50%;
            border:#fff;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            font-family: "Roboto Condensed","Arial Narrow",Arial,sans-serif;
            width:250px;
            margin: 0 auto;
            padding:0 6px;
        }
        form {
            font-family: "Roboto Condensed","Arial Narrow",Arial,sans-serif;
            width:220px;
            padding:2px 5px;
            background:#bbb;
            margin:5px auto;
            color:#008;
            box-shadow:1px 2px 3px #000;
            border:1px solid #008;
            border-radius:3px;
        }
        form input,form button{
            border:1px solid rgba(254,0,0,.3);
            width:200px;
            border-radius:3px;
            margin: 1px;
            background:#fff;
            cursor:default;
        }
        form button{
            background:linear-gradient(#000,#ccc,#000);
            color:#ccc;
            font-weight:600;
            font-family:Verdana,Arial;
            border-radius: 0 0 5px 5px;
            text-shadow:0 0 3px #000,0 0 3px #000;
            cursor:pointer;
        }
        .main {background:rgba(220,220,250,0.2);}
			
        .cars-list .car {
            background:linear-gradient(#fff,#ddd);
            width: 220px;
            float: left;
            border: 1px solid lightgray;
            border-radius: 5px;
			box-shadow:2px 3px 5px #ccc;
            padding: 2px;
            margin: 5px 2px;
        }
        .car {
            width:300px;
            height:100px;
        }

        .bl_btn{
            display:block;
            float: left;
            padding: 0 2px;
            font-weight:600;
            color:#f00;
            background: linear-gradient(#ddd,#fff);
            border:0;
            border-radius:3px;
            box-shadow:2px 2px 4px #aaa;
            margin:0 2px;
        }
        .car_find{
            width:300px;
            border-radius:3px;
            background:linear-gradient(#000,#ccc,#fff);
            box-shadow:2px 2px 4px #000;
            margin:5px;
            margin-left:15px;
        }

        .car_find .bl_btn
        {
            float: right;
            padding:0 5px;
            margin:0 0 0 2px;
            font-size:10px;
        }
        
        .cars-list .car > h3{
            margin-top: 0;
			color:#777;
            text-transform: capitalize;
            text-align: center;
			text-shadow: 0px  -1px 1px #008, 0px 1px 1px #000;
        }
		.cars-list .car > h4{
            margin-top: 0;
			color:gray;
            text-transform: capitalize;
            text-align: center;
        }
		.cars-list .car > .price{
            margin-top: 0;
			color:#352b02;
            text-transform: capitalize;
            text-align: center;
        }

        .cars-list::after {
            clear: both;
        }

        .cars-list::after,
        .cars-list::before{
            content: " ";
            display: table;
        }

        .usr  {
            position:fixed;
            left:5px;
            top:2px;
            background:linear-gradient(#ccc,#fff,#000);
            padding:0 10px 0 0 ;
            margin:0;
            border:1px solid #ccc;
            box-shadow:2px 2px 3px #000;
            border-radius:0 30px 30px 0 ;
        }
        .usr .uid-stat, .usr a,{
            padding:0;
            margin:0;
        }
        .hidden {
            display:none;
        }
        #hint{
            position:absolute;
            display:none;
            border:1px solid red;
        }
        form p{
            color:#fff;
            padding:0;
            margin:0;
        }

        form i{
            color:#000;
            font-size:11px;
            padding:0;
            margin:0;
            float:left;
        }

        #message {
            background:linear-gradient(#000,#fff,#000);
            width:300px;
            color:#fff;
            border:1px solid red;
            border-radius:5px;
        }
        .inf_car {
            position: absolute;
            width:250px;
            border:1px solid rgba(0,0,0,.5);
            background:linear-gradient(#000,#888);
            border-radius:3px;
        }

        
        #msg_cart{
            color:#1bb2fa;
            cursor:pointer;
        }

        .modalwindow {
            position:fixed;
            display:none; /* Скрываем модальное окно по умолчанию */
            z-index:9999;
            width:500px;
            background: #FF5722;
            -webkit-box-shadow: 0 8px 6px -6px black;
            -moz-box-shadow: 0 8px 6px -6px black;
            box-shadow: 0 8px 6px -6px black;
            -webkit-box-shadow: 0 8px 6px -6px black;
            -moz-box-shadow: 0 8px 6px -6px black;
            box-shadow: 0 8px 6px -6px black;
        }

        .close {
            float: right;
            margin-top: -47px;
            margin-right: 15px;
            width: 17px;
            height: 17px;
            display: block;
            padding: 10px;
            color: #fff;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            font-family: arial;
        }

        .js_car_model {
            height:55px;
        }
    </style>
<body>
<div class="main">
    <h1>Cars Shop Client</h1>
    <div class="forms_autorize">

        <!-- show errors reg/login -->
        <div id="result_form"></div>
        
        <!-- registration form -->
        <div class="form_user_registration">
            <form action="" id="registration_form" method="POST">
            <p>register</p>
            <input type="text" name="firstname" placeholder="firstname"><br />
            <input type="text" name="lastname" placeholder="lastname"><br />
            <input type="text" name="email" placeholder="email"><br />
            <i>password:</i><br />
            <input type="password" name="password" ><br />
            <i>password confirm:</i><br />
            <input type="password" name="confirmpassword"><br />
            <button name="send" id="btn">SEND</button>
            </form>
        </div>
        <!-- login form -->
        <div class="form_user_login">
                <form action="" id="login_form" method="POST">
                <p>login</p>
                <input type="text" name="email" placeholder="email"><br />
                <i>password:</i><br />
                <input type="password" name="password"><br />
                <button name="sendLogin" id="btn_login">SEND</button>
                </form>
        </div>
        <!-- search form -->
        <div class="search_form">


        <form action="" id="searchForm" method="POST">
        <input type="text" name="year" placeholder="year" value="">
        <input type="text" name="model" placeholder="model name">

        <select name="color">
        <option value="-1" disabled selected>COLOR</option>
        <option value="black">black</option>
        <option value="white">white</option>
        <option value="red">red</option>
        <option value="yellow">yellow</option>
        <option value="green">green</option>
        <option value="blue">blue</option>
        <option value="gray">gray</option>
        <option value="orange">orange</option>
        <option value="silver">silver</option>
        </select>

        <select name="engine">
        <option value="-1" disabled selected>ENGINE</option>
        <option value="1000">0 - 1000</option>
        <option value="2000">1000 - 2000</option>
        <option value="3000">2000 - 3000</option>
        <option value="4000">3000 - 4000</option>
        <option value="5000">4000 - 5000</option>
        <option value="6000">5000 - 6000</option>
        <option value="7000">6000 - 7000</option>
        <option value="8000">7000 - 8000</option>
        <option value="9000">8000 - 9000</option>
        <option value="10000">9000 - 10000</option>
        <option value="0">10000 - more</option>
        </select>

        <select name="price" form="searchForm">
        <option value="-1" disabled selected>PRICE</option>
        <option value="1">0 - 1000</option>
        <option value="10">1000 - 10000</option>
        <option value="100">10000 - 100000</option>
        <option value="1000">100000 - 1000000</option>
        <option value="10000">1000000 - 10000000</option>
        <option value="0">more</option>
        </select>

        <select name="maxspeed" form="searchForm">
        <option value="-1" disabled selected>SPEED</option>
        <option value="1">100</option>
        <option value="2">150</option>
        <option value="3">200</option>
        <option value="4">250</option>
        <option value="5">300</option>
        <option value="6">350</option>
        <option value="7">400</option>
        <option value="0">more</option>
        </select>
        <br />
        <button type="submit" class="searchButton" id="searchButton" name="searchButton" value="searchButton">
        Search Car</button>
        </form>



        </div>

    </div>
    <div class="uid-stat" id="uid"></div>
    <div class="cars-list" id="cars"></div>
    <hr />
    <div class="find-cars-list" id="carsF"></div>
<!-- just all cars list -->
</div>
    <script type="text/template" id="template_cars">
        <div class="car">
            <h3 class="js_car_model"></h3>
			<h4 class="js_car_year"></h4>
            <span class="js_car_price price"></span>
            <button class="js_car_show hidden bl_btn">Show</button>
            <button class="js_car_add hidden bl_btn">Add</button>
        </div>
    </script>

<!-- find cars list /////-->
</div>
    <script type="text/template" id="template_cars_find">
        <div class="car_find">
            <b class="js_car_find_model"></b>
			<span class="js_car_find_year"></span>
            <span class="js_car_find_price price"></span>
            <button class="js_car_show bl_btn">Show</button>
            <button class="js_car_add bl_btn">Add</button>
            
        </div>
    </script>

<!-- user login status messaging -->
    <script type="text/template" id="template_uid" >
        <div class="usr" >
            <span class="msg_login"></span><br />
            <span class="msg_user"></span><br />
            <span id="msg_cart" class="msg_cart"></span>    
        </div>
    </script>

<!-- info -->
        <div id="message(rename it to message)" class="hidden">
            <span class="name">Login or register for bay</span><br />
            <span class="email">Login or register for bay</span><br />
            <span class="token">Login or register for bay</span><br />
            <span class="auth">Login or register for bay</span><br />
        </div>
<!-- car click info -->
        <div id="inf_car" class="inf_car hidden">
        <div class="inf_model"></div>
        <span class="inf_price"></span><br/>
        <span class="inf_maxspeed"></span><br/>
        <span class="inf_year"></span><br/>
        <span class="inf_color"></span><br/>
        <span class="inf_engine"></span><br/>
        <button class="js_car_add bl_btn">Add</button>
        </div>

<!-- show cart modal -->
<div id="modal" class="modalwindow">
    <!-- Заголовок модального окна -->
    <h2>Cart</h2>
    <!-- кнопка закрытия окна определяется как класс close -->
    <button class="clear_cart_button">Clear</button>
    <a href="#" class="close">X</a>
    <div class="content">
    </div>
</div>




    <script src="js/jquery-3.4.1.js"></script>
    <script src="js/main.js"></script>
</body>
</html>