//var $url_serv = 'http://tc.geeksforless.net/~user11/REST/Server/api/';
var $url_serv = 'api/';
        (function($){
            var $login = getCookie('key');
            if ($login == undefined){$login = '0';} 
            var $cars = $('#cars');
            var $uid = $('#uid');
            var template_cars = $('#template_cars').text();

            var template_uid = $('#template_uid').text();
            var $usr = $(template_uid);
            if ($login.length > 5 ){
                $usr.find('.msg_login').html('<a href="#" id="logout">LOGOUT</a>');
            }
            $usr.appendTo($uid);

            function buildCars(data) {
                $(data).each(function(index, val) {
                    var $car = $(template_cars);
					//console.log(val);
                    $car.find('.js_car_model').text(val.model);
					$car.find('.js_car_year').text(val.year);
                    if ($login.length > 5){
                        //console.log($login);
                        $car.find('.js_car_price').html('('+val.id+') '+val.price+'$ <b>Bay</b>');
                    }else{
                        $car.find('.js_car_price').text(val.price+'$');
                    }
                    $car.appendTo($cars);
                });
            }

            $.ajax({
                url: $url_serv+'ShowCars/',
                method: 'GET',
                data: {
                    results: 50,
                    seed: 'test'
                },
                success: function(data) {
                    buildCars(data);
					//console.log(data);
                },
                error: function(e) {
                    console.log('ajax error', e);
                },
                complete: function() {
                    console.log('allways runned')
                }
            })

        }(jQuery))

		/////REGISTRATION////
			function sendAjaxForm(result_form, registration_form, url) {
			$.ajax({
                url:     url, //url страницы 
                type:     "POST", //метод отправки
                dataType: "html", //формат данных
                data: $("#"+registration_form).serialize(),  // Сеарилизуем объект
                success: function(response) { //Данные отправлены успешно
                    result = $.parseJSON(response);
					//console.log(result.regstatus);
					//result = response;
                    $('#result_form').html('registration: '+result.regstatus);
					
						if (result.regstatus == 'OK'){
						document.cookie = "uid="+result.email;document.cookie = "key="+result.key;
						}else{
							document.cookie = "uid="+result.email;document.cookie = "key";
						}
					
                },
                error: function(response) { // Данные не отправлены
                    $('#result_form').html('Ошибка. Данные не отправлены.');
                }
            });
							
			}
			
			$("#btn").click(
					function(){
						sendAjaxForm('result_form', 'registration_form', $url_serv+'Reg/');
						return false; 
					}
            );

            $("#logout").click(
                function(){
                    alert(document.cookie);
                document.cookie = "uid=0";
                document.cookie = "key=0";
                return false;
                }
            );


            function sendPUT(result_form,login_form,url) {
                
                $.ajax({
                    url:     url, //url страницы 
                    type:     "PUT", //метод отправки
                    dataType: "html", //формат данных
                    data: $("#"+login_form).serialize(),  // Сеарилизуем объект
                    success: function(response) { //Данные отправлены успешно
                    //console.log(response);
                        result = $.parseJSON(response);
                        //console.log(result);
                        //result = response;
                        $('#result_form').html('login: '+result.loginstatus);
                            if (result.loginstatus == 'OK'){
                                document.cookie = "uid="+result.email;document.cookie = "key="+result.key;
                            }else{
                                document.cookie = "uid="+result.email;document.cookie = "key=0";
                            }
                    },
                    error: function(response) { // Данные не отправлены
                        $('#result_form').html('Ошибка. Данные не отправлены.');
                    }
                });
							
			}

            ////////////////////////////////////
			
			/////LOGIN USER////
			function sendAjaxLogin(result_form, login_form, url) {
			$.ajax({
                url:     url, //url страницы 
                type:     "POST", //метод отправки
                dataType: "html", //формат данных
                data: $("#"+login_form).serialize(),  // Сеарилизуем объект
                success: function(response) { //Данные отправлены успешно
                //console.log(response);
                    result = $.parseJSON(response);
					//console.log(result);
					//result = response;
                    $('#result_form').html('login: '+result.loginstatus);
						if (result.loginstatus == 'OK'){
							document.cookie = "uid="+result.email;document.cookie = "key="+result.key;
						}else{
							document.cookie = "uid="+result.email;document.cookie = "key=0";
						}
                },
                error: function(response) { // Данные не отправлены
                    $('#result_form').html('Ошибка. Данные не отправлены.');
                }
            });
							
			}
			
			$("#btn_login").click(
					function(){
						// sendAjaxLogin('result_form', 'login_form', $url_serv+'Login/');
                        sendPUT('result_form', 'login_form', $url_serv+'Login/');
						return false; 
					}
            );
			
			function getCookie(name) {
            var matches = document.cookie.match(new RegExp(
                "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
            ));
            return matches ? decodeURIComponent(matches[1]) : undefined;
            }
       