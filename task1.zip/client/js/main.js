//var $url_serv = 'http://tc.geeksforless.net/~user11/REST/Server/api/';
var $url_serv = 'api/';
var $user_D = {};

localStorage.setItem(name,'');
$user_D = {
    email: '',
    token: '',
    name:  '',
    auth: 0
};
$user_D = JSON.parse(localStorage.getItem('user_D')) || '{}';
 $(".form_user_login input[name='email']").val($user_D.email);
 $('.search_form').slideUp();
if ($user_D.auth !== 1)
{
    $('.usr').slideUp();
    $('.form_user_registration').slideDown(300);
    $('.form_user_login').show(800);
}else{
    $('.search_form').slideDown(300);
    $('.usr').find('.msg_user').html('Hello ' + $user_D.name);
    $('.usr').find('.msg_login').html('<a href="#" id="logout">LOGOUT</a>');
    $('.usr').appendTo();
    $('.usr').slideDown(1000);
}



function buildCars(data) {  ////////////BUILD CARS////////////
    console.log(data);
    var $cars = $('#cars');
    var template_cars = $('#template_cars').text();
    $cars.hide();

    $(data).each(function(index, val) {
        var $car = $(template_cars);
        $car.find('.js_car_model').text(val.model);
        //$car.find('.js_car_year').text(val.year);
        if ($user_D.auth == 1){
            $('.form_user_login').hide();
            $('.form_user_registration').addClass('hidden');
            //$car.find('.js_car_price').html(val.price+'$ ');
            $car.find('.js_car_show').attr("id",val.id);
        }else{
            $car.find('.js_car_price').text(val.price+'$');
            $car.find('.js_car_show').css('display', 'none');
        }
        $car.appendTo($cars);
    });

    setTimeout(function() {
        $cars.show(500);
      }, 1000);
    
}



        (function($){
            var $msg = $('#message');
            $msg.find('.email').html('email:' + $user_D.email);
            $msg.find('.name').html('name:' + $user_D.name);
            $msg.find('.token').html('token:' + $user_D.token);
            $msg.find('.auth').html('auth:' + $user_D.auth);
            $msg.show(300);
            var $name = localStorage.getItem('name'); 
            var $uid = $('#uid');
            var template_uid = $('#template_uid').text();
            var $usr = $(template_uid);
            if ($user_D.auth == 1){
                $usr.find('.msg_user').html('Hello ' + $name);
                $usr.find('.msg_login').html('<a href="#" id="logout">LOGOUT</a>');
            }
            $usr.appendTo($uid);
            var $id = 0;
            var $cars_showing = {id: $id,token: $user_D['token']};
            $.ajax({
                url: $url_serv+'ShowCars/',
                method: 'GET',
                dataType: 'html',
                data: $cars_showing,
                success: function(data) {
                    result = $.parseJSON(data);
                        if ($user_D.auth == 1)
                        {
                            buildCars(result);
                        }
                },
                error: function(e) {
                    console.log('ajax error', e);
                },
                complete: function() {
                    console.log('allways runned')
                }
            })

        }(jQuery))

        function isAuth(url) {
            var $token = getCookie('token') || '0';
            // console.log('ghjdthbv ghjdthr');
            // console.log($token);
                    $.ajax({
                        url: url,
                        type: 'PUT',
                        dataType: 'html',
                        data: $token,
                        success: function(response) {
                            console.log(response);
                            //result = $.parseJSON(response);
                            result = response;
                            console.log('проверка:');
                            console.log(result);
                                if (result.auth == 0){
                                    $user_D.auth = 0;
                                    // document.cookie = 'uid=; expires=-1';
                                    // document.cookie = 'token=; expires=-1';
                                    // document.cookie = 'name=; expires=-1';                            
                                    return 0;
                                }else{
                                    $user_D.auth = 1;
                                    $('.usr').slideDown(500);
                                    return 1;
                                }
                        },
                        error: function(response) { // Данные не отправлены
                            $('#result_form').html('Ошибка проверки. Данные не отправлены.');
                        }
                    });  				
		}


		/////REGISTRATION////
			function sendPost(result_form, registration_form, url) {
                    $.ajax({
                        url:     url, //url страницы 
                        type:     "POST", //метод отправки
                        dataType: "html", //формат данных
                        data: $("#"+registration_form).serialize(),  // Сеарилизуем объект
                        success: function(response) { //Данные отправлены успешно
                            result = $.parseJSON(response);
                            $('#result_form').html('registration: '+result.regstatus);
                            if (result.regstatus == 'OK')
                            {
                                $user_D = {
                                    email: result.email,
                                    token: result.token,
                                    name:  result.name,
                                    auth: 1
                                };
                            }
                            setTimeout(function() {
                                location.reload();
                              }, 5000);
                        },
                        error: function(response) { // Данные не отправлены
                            $('#result_form').html('Ошибка. Данные не отправлены.');
                        }
                    });
							
			}
			
			$("#btn").click(
					function(){
						sendPost('result_form', 'registration_form', $url_serv+'Reg/');
						return false; 
					}
            );

            ////  CAR SHOW B ID
            function CarInfo(url) {
                
                $.ajax({
                    url:     url, 
                    type:     "GET", 
                    dataType: "html", 
                    data: {token: $user_D.token},  
                    success: function(response) { 
                        result = $.parseJSON(response);
                        
                        var $inf = $('#inf_car');
                        if ($user_D.auth == 1){
                            console.log(result[0]);
                            $inf.find('.inf_price').html(result[0].price+'$ ');
                            $inf.find('.inf_model').text('model:'+result[0].modelname);
                            $inf.find('.inf_maxspeed').text('speed:'+result[0].maxspeed);
                            $inf.find('.inf_year').text('yeard:'+result[0].year);
                            $inf.find('.inf_color').text('color:'+result[0].color);
                            $inf.find('.inf_engine').text('engine:'+result[0].engine);
                            $inf.appendTo($('#inf_car'));
                            $('#inf_car').show(200);
                        }

                    },
                    error: function(response) { // Данные не отправлены
                        $('#result_form').html('Ошибка. Данные не отправлены.');
                    }
                });
                        
            }

            $(document).on("click",".js_car_show",function(e){
                var id = $(this).attr("id");
                $('#inf_car').hide();
                CarInfo($url_serv+'ShowCars/' + id +"/");

                e = e || window.event; 
                e.preventDefault();
                var ypos = $(this).offset().top+24;
                var xpos = $(this).offset().left;
                var RealHint =  $('#inf_car');
                $(RealHint).css('top',ypos);
                $(RealHint).css('left',xpos);
                $(RealHint).toggle('fast'); 

                setTimeout(function() {
                    $('#inf_car').hide(500);
                  }, 5000);

            });

            ////  SEARCHING CAR
            function sendSearchAuto(searchForm, url) {
                //console.log( $("#"+searchForm).serialize() );
                var form = $("#"+searchForm);  
                var data = form.serialize()+'&token='+$user_D.token;
                $.ajax({
                    url:     url, 
                    type:     "POST", 
                    dataType: "html",
                    //contentType: "application/json",
                    data: data, 
                    success: function(response) { 
                        result = $.parseJSON(response);
                        //result = response;
                        console.log(result);
///////////////////////////////////////////////////////////////////////
                        if ($user_D.auth == 1){
                            buildCars(result);
                        }


                    },
                    error: function(response) { // Данные не отправлены
                        $('#result_form').html('Ошибка. Данные не отправлены.');
                    }
                });
                        
            }

            $(document).on("click","#searchButton",function(e){
                sendSearchAuto('searchForm', $url_serv+'SearchAuto/');
                return false;
                
            });
            
            /////////////////LOG OUT
            function sendLogoutPUT(result_form,url){

                $.ajax({
                    url: url,
                    type: 'PUT',
                    dataType: 'json',
                    data: $user_D,
                    success: function(response) {
                        //result = $.parseJSON(response);
                        //console.log(response);
                        if (response.loginstatus == 0)
                        {
                            $user_D = {
                                token: '',
                                name:  '',
                                auth: 0
                            };
                            localStorage.setItem('user_D', JSON.stringify($user_D));
                            $('.js_car_show').slideUp(300);
                            $('.usr').slideUp(300);
                        }
                        setTimeout(function() {
                            location.reload();
                          }, 2000);
                    },
                    error: function(response) { // Данные не отправлены
                        $('#result_form').html('Ошибка. Данные не отправлены.');
                    }
                });
            };
            
            
            
            ///////// LOGIN ////////
            function sendPUT(result_form,login_form,url) {
                //console.log($("#"+login_form).serialize());
                $.ajax({
                    url:     url, //url страницы 
                    type:     "PUT", //метод отправки
                    dataType: "html", //формат данных
                    data: $("#"+login_form).serialize(),  // Сеарилизуем объект
                    success: function(response) { //Данные отправлены успешно
                        result = $.parseJSON(response);
                        //result = response;

                            if (result.loginstatus == 1){
                                $('#result_form').html('login: Успешно');
                                $('.usr').slideDown(300);
                                localStorage.setItem('name', result.name);
                                $user_D = {
                                    email: result.email,
                                    token: result.token,
                                    name:  result.name,
                                    auth:  result.loginstatus
                                };

                                $('.form_user_registration').slideUp(400);
                                $('.form_user_login').hide(800);
                                
                            }else{

                                $user_D = {
                                    token: '',
                                    name:  '',
                                    auth: 0
                                };
                            }
                            localStorage.setItem('user_D',JSON.stringify($user_D));

                            setTimeout(function() {
                                location.reload();
                              }, 3000);
                    },
                    error: function(response) { // Данные не отправлены
                        $('#result_form').html('Ошибка логина. Данные не отправлены.');
                    }
                });
							
			}

            
			
			/////LOGIN USER////
			// function sendAjaxLogin(result_form, login_form, url) {
			// $.ajax({
            //     url:     url, //url страницы 
            //     type:     "POST", //метод отправки
            //     dataType: "html", //формат данных
            //     data: $("#"+login_form).serialize(),  // Сеарилизуем объект
            //     success: function(response) { //Данные отправлены успешно
            //     //console.log(response);
            //         result = $.parseJSON(response);
			// 		//console.log(result);
			// 		//result = response;
            //         $('#result_form').html('login: '+result.loginstatus);
			// 			if (result.loginstatus == 'OK'){
            //                 document.cookie = "uid="+result.email;
            //                 document.cookie = "name="+result.name;
            //                 document.cookie = "token="+result.token;
			// 			}else{
            //                 document.cookie = "uid";
            //                 document.cookie = "token=0";
            //                 document.cookie = "name";
            //             }
            //             location.reload();
            //     },
            //     error: function(response) { // Данные не отправлены
            //         $('#result_form').html('Ошибка. Данные не отправлены.');
            //     }
            // });
							
			// }
            
            $("#btn_login").click(
                function(){
                    // sendAjaxLogin('result_form', 'login_form', $url_serv+'Login/');
                    sendPUT('result_form', 'login_form', $url_serv+'Login/');
                    return false; 
                }
            );

			$(document).on('keyup',".form_user_login input[name='email']",function(e){
                $user_D.email = $(".form_user_login input[name='email']").val();
                localStorage.setItem('user_D' ,JSON.stringify($user_D));
            });
			
			function getCookie(name) {
            var matches = document.cookie.match(new RegExp(
                "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
                ));
                return matches ? decodeURIComponent(matches[1]) : undefined;
            }

            $("#logout").click(
                function(){
                    sendLogoutPUT('result_form',$url_serv+'Logout/');
                    return false;
                }
            );  

            

            // var hint = $('#hint');
            // $(document).on({
            //     mouseenter: function(){
            //         hint.slideDown(1000);
            //     },
            //     mouseleave: function(){
            //         hint.slideUp(1000);
            //     },
            //     mousemove: function(e){
            //         hint.css({top: e.pageY+100, left: (e.pageX)+100});
            //     }
            //     //alert(id); 
            // },'.carrrr');