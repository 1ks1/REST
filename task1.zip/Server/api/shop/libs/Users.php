<?PHP 
class Users
{



    function putIsAuth($userData)
    {
        return ['auth'=>1];
        if (!isset($userData['token']))
        return ['auth'=>'have_no_token'];

        //ищем мыло и токен в базе
        
            $q      = "select count(email) from users " . 
                    "WHERE email='" . $userData['token'] . "'";
            $stmt   = $this->pdo->prepare($q);
            $stmt->execute();
            $res    = $stmt->fetchAll();

            if (is_array($res) && (1 == $res[0]['count(email)']))
            return ['auth'=>1];
            return ['auth'=>0];
 
    }


    function getCrypt($p = '')
	{
        if (is_array($p))
            $p = $p[0];
        if (strlen($p) < 1 || $p == 'Crypt')
            return 'Please enter yo string';
        $clearTextPassword = $p;
        // Encrypt password
        $password = crypt($clearTextPassword, base64_encode($clearTextPassword));
        return $password;
    }


    function postReg($userData)
    {   
        $regstatus  = '';
        $token = md5(rand(1,10000)); //случайный токен
        //проверим что пришло
        if (!(isset($userData['email']) || 
            isset($userData['password']) ||
            isset($userData['confirmpassword']) ||
            isset($userData['firstname']) ||
            isset($userData['lastname'])))
            return ['regstatus'=>'fields empty'];

        if (strlen($userData['email']) < 5)
        return ['regstatus'=>'email error'];
        
        $eml    = $userData['email'];
        $p      = $userData['password'];
        $c      = $userData['confirmpassword'];
        $f      = $userData['firstname'];
        $l      = $userData['lastname'];

        //совпадают ли пароли
        if ($p !== $c)
        return ['regstatus'=>'confirm password'];
        // типа проверяем имя
        if ((strlen($f) < 3) || (strlen($l) < 3))
        return ['regstatus'=>'Name < 3 letters!'];
        //ищем мыло в базе
        $q      = 'select count(email) from users where email=' . "'$eml'";
        $stmt   = $this->pdo->prepare($q);
        $stmt->execute();
        $res    = $stmt->fetchAll();
        //если есть, говорим, что есть
        if (is_array($res) && $res[0]['count(email)'] > 0)
        {
            $regstatus = 'User exists!';
        } 
        else 
        {
            try
            {
                $ph = md5($p);
                //cоздадим токен 
                date_default_timezone_set('UTC');
                $d = new DateTime();
                $ts = $d->getTimestamp();
                $token = md5($eml . $p . $ts);
                $token = $this->getCrypt($token);
                //пишем юзера в базу
                $q = 'INSERT INTO users ' .
                "(name,lastname,email,password,token)" . 
                " values ('$f','$l','$eml','$ph','$token') ";
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();
                $regstatus='OK';
            }
            catch(PDOException $e) 
            {  
                //$result = 'Reg db error!' . $e->getMessage();
                $regstatus='Error' . $e->getMessage();
            }
            //$stmt->execute();
        }
        //отошлем клиенту статус
        return ['regstatus'=>$regstatus];
    }

    function putLogOut($userData)
    {
        //если не пришел емейл в ответ отсылаем логаут
        if (empty($userData['email']))
        return ['loginstatus'=>0,'token'=>'0'];
        
        $eml    = $userData['email'];
        $loginstatus = 0;
        $token = md5(rand(1,10000)); //случайный псевдо токен
        $q = "SELECT email from users WHERE email='$eml'";
                try
                {
                    $stmt = $this->pdo->prepare($q);
                    $stmt->execute();
                    $res = $stmt->fetchAll();
                    if (count($res) == 1)
                    {
                        //удалим токен юзера
                        $q     = "UPDATE users SET token = '$token' WHERE email = '$eml'";
                        $stmt = $this->pdo->prepare($q);
                        $stmt->execute();
                        
                    } else {
                        $loginstatus=0;
                    } 
                }
                catch(PDOException $e) 
                {  
                    $loginstatus='Error' . $e->getMessage();
                }
                $token = '__' + md5(rand(1,10000)); //случайный псевдо токен
        return ['loginstatus'=>$loginstatus,'token'=>$token];
    }



    function putLogin($userData)
    {
        
        if (empty($userData['email']))
        return ['loginstatus'=>'email is wrong'];

        if (empty($userData['password']))
        return ['loginstatus'=>'password is wrong'];

        if (strlen($userData['email']) < 5 || strlen($userData['password']) < 6)
        return ['loginstatus'=>'fields is too short'];
        
        $token = md5(rand(1,10000)); //случайный псевдо токен
        $name = '';
        $uid = '';
        $loginstatus = 0;

        $eml    = $userData['email'];
        $p      = $userData['password'];
        $ph     = md5($p);

        //проверим мыло и пароль
        $q      = 'SELECT id,name,email,password from users WHERE ' .
                "email='$eml' and password='$ph'";
                
            try
            {
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();
                $res = $stmt->fetchAll();
                
                if (count($res)>0)
                {
                    $name   = $res[0]['name'];
                    $uid    = $res[0]['id'];
                    $loginstatus=1;
                } else {
                    $loginstatus='Wrong user or password';
                } 
            }
            catch(PDOException $e) 
            {  
                $loginstatus='Error' . $e->getMessage();
            }
            
            if ($loginstatus == 1)
            {
                //cоздадим токен 
                date_default_timezone_set('UTC');
                $d = new DateTime();
                $ts = $d->getTimestamp();
                $token = md5($eml . $p . $ts);
                $token = $this->getCrypt($token);
                //и запишем в базу
                 $q = "UPDATE users SET token = '$token' " .
                 "WHERE email = '$eml'";
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();
            }
            //отошлем токен, мыло, имя и статус клиенту
        return ['loginstatus'=>$loginstatus,'email'=>$eml,'user_id'=>$uid,'name'=>$name,'token'=>$token];
    }
}