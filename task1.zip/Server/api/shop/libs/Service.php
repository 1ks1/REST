<?PHP 
include ('DB.php');
class Service extends DB
{

    

    function getSayHello($name = false)
    {
        if (!$name)
        $res = 'Hello guest!';
        if (isset($name[0]) && strlen($name[0]) > 0 )
        $res = 'Hello, ' . $name[0] . '!';
        return ['echo'=>$res];
    }

    function getShowCars($id = false)
    {
        if ($id !== false)
        $q = 'select * from cars';
        if (isset($id[0]) && is_numeric($id[0]) )
        $q = 'select * from cars where id=' . $id[0];
        $stmt = $this->pdo->prepare($q);
        $stmt->execute();
        $res = $stmt->fetchAll();
        return [$res];
    }

    function getHelp($id = false)
    {
        $res = get_class_methods($this);
        return [$res];
    }

    function strValid($str)
    {
        $str = htmlspecialchars(trim($str));
        if (strlen($str)<1)
        return false;
        return $str;
    }

    //UD = email, firstN, lastN, password
    function postRegistration($userData)
    {
        //if email exists then error user exists
        //else if passwd(s) equally then write user
        //send session login (user ID and md5)
        return ['Auth'=>'Testing'];
    }

    //UD = email, firstN, lastN, password
    function postLogin($userData)
    {
        //if email exists then
        //eif  md5(passwd) = in database
        //send session login (user ID and md5)
        //else send login error
        return ['Login'=>'Testing'];
    }

    

   
}