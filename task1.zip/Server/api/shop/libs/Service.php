<?PHP
///////////////////////////
///servers methods      ///
///databse parent class ///
///want to do config errors
///have no valid emails yet
///////////////////////////

include ('DB.php');
include ('Users.php');
class Service extends Users
{
    protected $pdo;

    function __construct()
    {
        $this->pdo = DB::connect();
    }


    function getShowCars($params = false)
    {
        $aut['auth'] = 0;
        
        if (isset($params['token']))
        {
            $res = $this->putisAuth(['token'=>$params['token']]);

            if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];
        } else {
            $aut['auth'] = 0;
        }

        if ($aut['auth'] == 0)
        return ['auth'=>0];


        
        if (isset($params[0]))
        $id = $params[0];
        if (isset($params['id']))
        $id = $params['id'];
        if (is_numeric($id) && $id > 0)
        {
            $id = (integer)$id;
            $q = "select * from cars where id='$id'"; //test variant query
        } 
        else 
        {
            $q = 'select * from cars'; //test variant query
        }
        
        if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
        }


        return $res;
    }

    function getMd5($p = '')
	{
        if (is_array($p))
            $p = $p[0];
        if (strlen($p) < 1 || $p == 'Md5')
            return 'Please enter yo string';
        return md5($p);
	}
	
    function getHelp($id = false)
    {
        $res = get_class_methods($this);
        return $res;
    }

    function strValid($str)
    {
        $str = htmlspecialchars(trim($str));
        if (strlen($str)<1)
        return false;
        return $str;
    }

    

   
    

   
}