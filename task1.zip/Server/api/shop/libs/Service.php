<?PHP
///////////////////////////
//shop      methods///
///////////////////////////

include ('DB.php');
include ('Users.php');
class Service extends Users
{
    protected $pdo;

    function __construct()
    {
        $this->pdo = DB::connect();
    }


    function getShowCars($params = false)
    {
        $aut['auth'] = 0;
        //проверим токен
        if (isset($params['token']))
        {
            $res = $this->putisAuth(['token'=>$params['token']]);
            if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];
        } else {
            $aut['auth'] = 0;
        }

        if ($aut['auth'] == 0)
        return ['auth'=>0];


        
        if (isset($params[0]))
        $id = $params[0];
        if (isset($params['id']))
        $id = $params['id'];
        if (is_numeric($id) && $id > 0)
        {
            $id = (integer)$id;
            //$q = "select * from cars where id='$id'"; //test variant query
            $q = 'SELECT cars.model modelname,cars.id ID,cars.year,engines.value engine,colors.color,cars.maxspeed,cars.price 
        FROM cars,colors,engines 
        WHERE engine_id = engines.id and colors.id = color_id and cars.id =' . $id;
        } 
        else 
        {
          $q  = 'SELECT cars.id,cars.model,brands.brand FROM cars,brands ';
          $q .= 'WHERE brands.id = brand_id';
        }
        
        if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
        }


        return $res;
    }

    function getMd5($p = '')
	{
        if (is_array($p))
            $p = $p[0];
        if (strlen($p) < 1 || $p == 'Md5')
            return 'Please enter yo string';
        return md5($p);
	}
	
    function getHelp($id = false)
    {
        $res = get_class_methods($this);
        return $res;
    }

    function strValid($str)
    {
        $str = htmlspecialchars(trim($str));
        if (strlen($str)<1)
        return false;
        return $str;
    }

    

   function postSearchAuto($type)
    {
    
      //return ['test'=>$type];
	      $aut['auth'] = 0;
        //проверим токен
        if (isset($type['token']))
        {
            $res = $this->putisAuth(['token'=>$type['token']]);
            if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];
        } else {
            $aut['auth'] = 0;
        }

        if ($aut['auth'] == 0)
        return ['auth'=>0];
		
        //return ['test'=>$type['year']];
      if (isset($type['year']) && is_numeric($type['year']))
      { 
        //год обязательно, ищем в паре с 'модель' или частично 

        $cq = 'SELECT cars.id,cars.model,cars.year,engines.value engine,colors.color,cars.maxspeed,cars.price ' . 
        'FROM cars ' .
        'INNER JOIN engines ON engines.id=engine_id ' . 
        'INNER JOIN colors ON colors.id = color_id';

        $y = $type['year'];
        if (isset($type['model']) && strlen($type['model']) > 1)
        {
          $dq = 'SELECT * FROM (' . $cq . ") AS A WHERE model LIKE '%" . 
          $type['model'] . "%' AND $y=year GROUP BY id";
        }
        else 
        {
          $dq = 'SELECT * FROM (' . $cq . ") AS A WHERE $y=year GROUP BY id";
        }

        if (strlen($dq)<1)
        $dq = $cq;
        $q = $dq;
        if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $r = $stmt->fetchAll();
        }

    
        //сортируем массивы по параметрам
        //если задан цвет
        if (isset($type['color']) && strlen($type['year'])>1)
        {
          $arr2 = [];
            foreach ($r as $k=>$v)
            { 
              $c1 = strtolower(($v['color']));
              $c2 = strtolower(trim($type['color']));
              if ($c1 == $c2)
              $arr2[] = $v;
            }
          $r = $arr2;
        }

        //если двиг задан, выберем диаппазон "до значения"
        if (isset($type['engine']) && strlen($type['engine'])>1)
        {
          $arr2 = [];
            foreach ($r as $k=>$v)
            { 
              $c1 = strtolower(($v['engine']));
              $c2 = strtolower(trim($type['engine']));
              if (($c1 <= $c2) && ($c1 ))
              $arr2[] = $v;
            }
          if (! 0 == (integer)strtolower(trim($type['engine'])))
          $r = $arr2;
        }

        //если cкорость задано, выберем диаппазон "до значения"
        if (isset($type['maxspeed']) && strlen($type['maxspeed'])>1)
        {
          $arr2 = [];
            foreach ($r as $k=>$v)
            { 
              $c1 = strtolower(($v['maxspeed']));
              $c2 = strtolower(trim($type['maxspeed']));
              if ($c1 <= $c2)
              $arr2[] = $v;
            }
          if (! 0 == (integer)strtolower(trim($type['maxspeed'])))
          $r = $arr2;
        }

        //если цена задано, выберем диаппазон "до значения"
        if (isset($type['price']) && strlen($type['price'])>1)
        {
          $arr2 = [];
            foreach ($r as $k=>$v)
            { 
              $c1 = strtolower(($v['price']));
              $c2 = strtolower(trim($type['price']));
              if ($c1 <= $c2)
              $arr2[] = $v;
            }
          if (! 0 == (integer)strtolower(trim($type['price'])))
          $r = $arr2;
        }
        


        $count = count($r);
        if (1 > $count)
        return 'Server:Sorry. Not found for this parameters';

        return $r;
      }
      else
      {
        return 'Server:Error. year example: [2006]';
      }
    }
    

   
}