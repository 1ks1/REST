<?PHP
include ('libs/Service.php');
//header('Content-Type: text/javascript');
//header('Content-Type: text/css');
//header('Content-Type: text/html; charset=utf-8'); 
//header('Content-Type: application/pdf');
//header('Content-Disposition: attachment; filename="downloaded.pdf"');
//readfile('original.pdf');
//header('Content-Type: image/gif'); 
//header('Content-Type: image/png'); 
//header('Content-Type: image/jpg'); 
//header('Content-Type: application/json');
//header("Location: http://www.example.com/");
//header("HTTP/1.0 404 Not Found");


// $headers = array (
//     'User-Agent: Babytoy/0.5',
//     'Referer: http://refrefref.ref/omg.pl'
//     );
//     $html = request_socket('http://127.0.0.1/showmeheaders.php', $headers);
//     echo $html;

class Shop 
{
    protected $url;
    protected $uri;
    protected $action;
    protected $parameters;
    protected $service;
    protected $method;

    function __construct()
    {
        $this->method = $_SERVER['REQUEST_METHOD'];
        $this->uri = $_SERVER['REQUEST_URI'];
        $this->url = explode('/',$_SERVER['REQUEST_URI']);
        $isApi = false;
        $isMethod = false;
        $parameters = [];
        $this->service = new Service;
        
        //PARSING URL (set params)
        foreach($this->url as $value)
        {
            $value = $this->validator($value);


            if ($isApi)
            {
                $this->parameters[] = $value;
            }

            if (strtolower(trim($value)) == 'api')
            {
                $isApi = true;
            }

        }
        if (count($this->parameters) > 0)
        {
            //set Action name
            $this->action = ($this->parameters[0]);
            //уберем расширение
            $info = pathinfo($this->action);
            if (isset($info['extension']))
            $this->action = basename($this->action,'.' . $info['extension']);
            //print_r($this->action);
            //удалим конец массива (елемент)
            array_shift($this->parameters);
        }
        
    }


    function validator($str)
    {
        $str = htmlspecialchars(trim($str));
        return $str;
    }


    function parseMethod()
    {
        $method = $this->method;
        $fName = $this->action;
        $fParams = $this->parameters;
        $viewType = '.json';
        $res = '';

        switch ($method) {
            case 'GET':
                if (strlen($this->action) > 0)
                {
                    $path_parts = pathinfo($this->uri);
                    //берем последний кусок urlа
                    $viewType = array_pop($fParams);
                    //берем что до ?
                    $viewType = explode('?', $viewType)[0];
                    //берем что после точки
                    if(isset($path_parts['extension']))
                    $viewType = $path_parts['extension'];
                    //ложим обратно как параметр без мусора
                    array_push($fParams,$path_parts['filename']);
                    //print_r($viewType);
                    $res = $this->runAction('get' . $fName, $fParams);

                }
                break;
            case 'POST':
                $fParams = $_POST;
                $res = $this->runAction('post' . $fName, $fParams);
                break;
            case 'PUT':
                $fParams = $_PUT;
                $res = $this->runAction('put' . $fName, $fParams);
                break;
            case 'DELETE':
                $res = $this->runAction('delete' . $fName, $fParams);
                break;
            default:
                return false;
        }

        $this->showRes($res, $viewType);
    }


    function runAction($fName, $params = false)
    {
        $r = false;
            if (method_exists($this->service, $fName))
            {
                $r = call_user_func([$this->service, $fName], $params);
            }
            
                
        return $r;
    }

    private function showRes($result, $viewType = 'json')
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: text/html; charset=utf-8'); 
        header('Cache-Control: no-cache');

        if (!$result)
        {
            header("HTTP/1.1 400 Bad Request Api");
            $result = '404 No such action!';
        }
        
 
        //ставим заголовок
        switch ($viewType) {
            case 'txt':
                header('Content-type: text/plain');
                print_r($result);
                break;
            case 'html':
                header('Content-type: text/html');
                echo ($result);
                break;
            case 'xml':
                header('Content-type: application/xml');
                echo $this->toXml($result);
                break;
            default:
                header('Content-Type: application/json');
                echo json_encode($result);
                break;
        }
    }

    function array_to_xml($array, &$xml) 
    {
        foreach($array as $key => $value) 
        {
            if(is_array($value)) 
            {
                if(!is_numeric($key))
                {
                    $subnode = $xml->addChild("$key");
                    $this->array_to_xml($value, $xml);
                } else {
                    $this->array_to_xml($value, $xml);
                }
            } else {
                $xml->addChild("$key","$value");
            }
        }
        return $xml;
    }

    private function toXml($data)
    {
        $xml = new SimpleXMLElement('<root/>');
        $node = $xml->addChild('Projects');
        $res = $this->array_to_xml($data, $node);
        return $res->asXML();
        
    }



}

$cl = new Shop();

$cl->parseMethod();

// echo "\n<pre>DEBUG INFO \n";
// echo 'REQUEST Method:';
// print_r($_SERVER['REQUEST_METHOD']);
// echo "\n";
// $arr = explode('/',$_SERVER['REQUEST_URI']);
// echo " \n";
// if (isset($arr[5]) && !empty($arr[5]))
// {
//     echo 'parameter 1: ' . $arr[5];
//     echo " \n";
// }
// echo " URL: \n";
// print_r($_SERVER['REQUEST_URI']);
// $data = [
// 'remote_host'=>$_SERVER['REMOTE_ADDR']
// ];
// $data ['url'] = explode('/',$_SERVER['REQUEST_URI']);
// echo json_encode($data);