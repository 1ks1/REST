//var $url_serv = 'http://tc.geeksforless.net/~user11/REST/Server/api/';
var $url_serv = 'api/';
        (function($){
            var $login = getCookie('key');
            var $name = getCookie('name');
            if ($login == undefined){$login = '0';} 
            var $cars = $('#cars');
            var $uid = $('#uid');
            var template_cars = $('#template_cars').text();

            var template_uid = $('#template_uid').text();
            var $usr = $(template_uid);
            if ($login.length > 5 ){
                
                $usr.find('.msg_user').html('Hello ' + $name);
                $usr.find('.msg_login').html('<a href="#" id="logout">LOGOUT</a>');
            }
            $usr.appendTo($uid);



            function buildCars(data) {
                $(data).each(function(index, val) {
                    var $car = $(template_cars);
					//console.log(val);
                    $car.find('.js_car_model').text(val.model);
					$car.find('.js_car_year').text(val.year);
                    if ($login.length > 5){
                        //console.log($login);
                        $('.form_user_login').addClass('hidden');
                        $('.form_user_registration').addClass('hidden');
                        $car.find('.js_car_price').html(val.price+'$ ');
                        $car.find('.js_car_bay').attr("id",val.id);
                    }else{
                        $car.find('.js_car_price').text(val.price+'$');
                        $car.find('.js_car_bay').css('display', 'none');
                    }
                    $car.appendTo($cars);
                });
            }

            $.ajax({
                url: $url_serv+'ShowCars/',
                method: 'GET',
                data: {
                    results: 50,
                    seed: 'test'
                },
                success: function(data) {
                    buildCars(data);
					//console.log(data);
                },
                error: function(e) {
                    console.log('ajax error', e);
                },
                complete: function() {
                    console.log('allways runned')
                }
            })

        }(jQuery))

		/////REGISTRATION////
			function sendAjaxForm(result_form, registration_form, url) {
			$.ajax({
                url:     url, //url страницы 
                type:     "POST", //метод отправки
                dataType: "html", //формат данных
                data: $("#"+registration_form).serialize(),  // Сеарилизуем объект
                success: function(response) { //Данные отправлены успешно
                    result = $.parseJSON(response);
					//console.log(result.regstatus);
					//result = response;
                    $('#result_form').html('registration: '+result.regstatus);
					
						if (result.regstatus == 'OK'){
                        document.cookie = "uid="+result.email;
                        document.cookie = "key="+result.key;
                        document.cookie = "name="+result.name;
						}else{
                            document.cookie = "uid="+result.email;document.cookie = "key";
                            document.cookie = "name="+'guest';
						}

                },
                error: function(response) { // Данные не отправлены
                    $('#result_form').html('Ошибка. Данные не отправлены.');
                }
            });
							
			}
			
			$("#btn").click(
					function(){
						sendAjaxForm('result_form', 'registration_form', $url_serv+'Reg/');
						return false; 
					}
            );


            $(document).on("click",".js_car_bay",function(e){
                var id = $(this).attr("id");
                //alert(id); 
            });
            
            

                /////////////////LOG OUT

                $("#logout").click(
                    function(){
                    document.cookie = "uid=0";
                    document.cookie = "key=0";
                    return false;
                    }
                );

            function sendlogoutPUT(result_form,logout_form, url ){
                //var $token = getCookie('token');
                //var $email = getCookie('uid');
                
                $.ajax({
                    url:     url, //url страницы 
                    type:     "PUT", //метод отправки
                    dataType: "html", //формат данных
                    data: $("#"+logout_form).serialize(),  // Сеарилизуем объект
                    success: function(response) { //Данные отправлены успешно
                    //console.log(response);
                        result = $.parseJSON(response);
                        //console.log(result);
                        //result = response;
                        $('#result_form').html('login: '+result.loginstatus);
                            if (result.loginstatus == 'OK'){
                                document.cookie = "uid="+result.email;
                                document.cookie = "key="+result.key;
                                document.cookie = "name="+result.name;
                            }else{
                                document.cookie = "uid="+result.email;document.cookie = "key=0";
                                document.cookie = "name="+'guest';
                            }
                    },
                    error: function(response) { // Данные не отправлены
                        $('#result_form').html('Ошибка. Данные не отправлены.');
                    }
                });
							
			}


            function sendPUT(result_form,login_form,url) {
                
                $.ajax({
                    url:     url, //url страницы 
                    type:     "PUT", //метод отправки
                    dataType: "html", //формат данных
                    data: $("#"+login_form).serialize(),  // Сеарилизуем объект
                    success: function(response) { //Данные отправлены успешно
                    //console.log(response);
                        result = $.parseJSON(response);
                        //console.log(result);
                        //result = response;
                        $('#result_form').html('login: '+result.loginstatus);
                            if (result.loginstatus == 'OK'){
                                document.cookie = "uid="+result.email;
                                document.cookie = "key="+result.key;
                                document.cookie = "name="+result.name;
                            }else{
                                document.cookie = "uid="+result.email;document.cookie = "key=0";
                                document.cookie = "name="+'guest';
                            }
                    },
                    error: function(response) { // Данные не отправлены
                        $('#result_form').html('Ошибка. Данные не отправлены.');
                    }
                });
							
			}

            ////////////////////////////////////
			
			/////LOGIN USER////
			function sendAjaxLogin(result_form, login_form, url) {
			$.ajax({
                url:     url, //url страницы 
                type:     "POST", //метод отправки
                dataType: "html", //формат данных
                data: $("#"+login_form).serialize(),  // Сеарилизуем объект
                success: function(response) { //Данные отправлены успешно
                //console.log(response);
                    result = $.parseJSON(response);
					//console.log(result);
					//result = response;
                    $('#result_form').html('login: '+result.loginstatus);
						if (result.loginstatus == 'OK'){
                            document.cookie = "uid="+result.email;document.cookie = "key="+result.key;
                            document.cookie = "name="+result.name;document.cookie = "token="+result.token;
						}else{
                            document.cookie = "uid="+result.email;document.cookie = "key=0";
                            document.cookie = "token=0";
                            document.cookie = "name="+" ";
						}
                },
                error: function(response) { // Данные не отправлены
                    $('#result_form').html('Ошибка. Данные не отправлены.');
                }
            });
							
			}
			
			$("#btn_login").click(
					function(){
						// sendAjaxLogin('result_form', 'login_form', $url_serv+'Login/');
                        sendPUT('result_form', 'login_form', $url_serv+'Login/');
						return false; 
					}
            );
			
			function getCookie(name) {
            var matches = document.cookie.match(new RegExp(
                "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
            ));
            return matches ? decodeURIComponent(matches[1]) : undefined;
            }
       