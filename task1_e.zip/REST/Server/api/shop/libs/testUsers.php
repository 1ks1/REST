<?PHP 
include ('DB.php');
include ('Users.php');


function putIsAuth($userData)
    {
        //return ['auth'=>1];
        if (!isset($userData['token']))
        return ['auth'=>'have_no_token'];

        //ищем мыло и токен в базе
        
            $q      = "select count(email) from users " . 
                    "WHERE token='" . $userData['token'] . "'";
            try
            {
                $stmt   = DB::connect()->prepare($q);
                
                $stmt->execute();
                $res    = $stmt->fetchAll();
            }catch(PDOException $e) 
            {  
                $pdo = $e->getMessage();
                //fix database error messages coz encoding is mixed in my sql server probably
                $var = mb_convert_encoding($pdo, "utf-8", "windows-1251");
                if (preg_match("/([а-я]+)/ui", $var))
                $res = $var;
            }
            

            if (is_array($res) && (1 == $res[0]['count(email)']))
            return ['auth'=>1];
            return ['auth'=>0];
 
    }

$userData['token'] = 'MWhISx3JBZZ4Y';

$res = putIsAuth($userData);


print_r($res);