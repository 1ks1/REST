<?PHP
include ('configDb.php');
 class DB 
 {
    protected $pdo;

    function getPdo()
    {
        return $this->pdo;
    }

    function __construct()
    {
        $this->pdo = $this->connect();
    }

    static function connect()
     {
        $dbtype = DBTYPE;
        if (1 == $dbtype)//mysql
        {
            $dsn = "mysql:host=" . HOST . 
            ";dbname=" . DB . ";charset=" . CHARSET;
            $user = USER;
            $password = PASSWORD;
        }

        if (2 == $dbtype)//pgsql
        {
                $dsn = "pgsql:host=" . PHOST . 
                ";dbname=" . PDB;
                $user = PUSER;
                $password = PPASSWORD;
        }

        $opt= [
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES  => true
            //PDO::ATTR_EMULATE_PREPARES  => false  #coz validator
        ];

        try
        {
            $pdo = new PDO($dsn, $user, $password, $opt);
        }
        catch(PDOException $e) 
        {  
            $pdo = $e->getMessage();
            //fix database error messages coz encoding is mixed in my sql server probably
            $var = mb_convert_encoding($pdo, "utf-8", "windows-1251");
            if (preg_match("/([а-я]+)/ui", $var))
            $pdo = $var;
        }
        return $pdo; 
    }
 }